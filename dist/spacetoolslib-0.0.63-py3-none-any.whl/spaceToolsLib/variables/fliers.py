
fliers = ['high','low']