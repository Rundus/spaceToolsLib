
fliers = ['high','low']